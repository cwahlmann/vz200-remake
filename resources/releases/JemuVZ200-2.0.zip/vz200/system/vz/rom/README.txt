In this folder the ROM-Files for the VZ200 must be put:

The character-tables:					VZ.CHR

The operating system and Basic-ROM:		VZBAS12.ROM
