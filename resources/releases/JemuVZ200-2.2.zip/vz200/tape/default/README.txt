Default-folder, that stores the tape-data.
